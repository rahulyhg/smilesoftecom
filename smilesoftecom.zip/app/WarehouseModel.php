<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WarehouseModel extends Model
{
    protected $table = 'warehouse';
    public $timestamps = false;
}
